#!/usr/bin/env bash
make
# A script that builds your compiler.
